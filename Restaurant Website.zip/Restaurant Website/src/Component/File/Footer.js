import React from 'react'

export default function Footer() {
  return (
    <div>
      <div class="b-example-divider"></div>
        <div class="container">
        <footer class="py-3 my-4">
        <div className='border-bottom pb-3 mb-3'></div>
          <p class="text-center text-muted ">&copy; 2024 Anchal</p>
          
        </footer>
        </div>
    </div>
  )
}
